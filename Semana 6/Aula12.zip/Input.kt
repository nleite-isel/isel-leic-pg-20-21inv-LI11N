
fun readInt(quest :String) :Int {
	print("$quest? ")
    return readLine()!!.trim().toInt()
}
