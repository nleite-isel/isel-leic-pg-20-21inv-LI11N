import kotlin.math.ceil

fun main() {
    print("Quantia em Euros? ")
    val amount =  readLine()!!.toDouble()
    val amountCent : Int = ceil(4.31 * 100).toInt()

//    if (amount == 4.31) // Not correct due to approximation errors
//    val epsilon = 1e-6
//    val epsilon = 1e-3

//    if (amount - 4.31 <= epsilon) // Not correct due to approximation errors
//        println("OK")

//    val v = 1.0 / 3 // 0.333333...
//    if (v == 0.33) // Not correct due to approximation errors
//        println("OK")
//    if (v - 0.33 <= epsilon) // Not correct due to approximation errors
//        println("OK 1")

    println(amountCent)

}