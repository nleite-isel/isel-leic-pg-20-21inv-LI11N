

//1. (Union)
//Ler o início e o fim de dois intervalos limitados fechados de valores inteiros e escrever o
//intervalo de reunião entre eles. Caso os intervalos não se intercetem a reunião é formada
//pelos dois intervalos (Ex: A=[2,5] e B=[6,9] então A+B=[2,5]+[6,9]).


fun main() {
    print("Intervalo A? ")
    val low1 =  readLine()!!.toInt()
    val high1 =  readLine()!!.toInt()
    print("Intervalo B? ")
    val low2 =  readLine()!!.toInt()
    val high2 =  readLine()!!.toInt()
    //
    // Check if not intersects
    //
    val low : Int
    val high : Int
    if (high1 < low2 || high2 < low1) {
        // The intervals don't intersect
        print("A+B=")
        if (high1 < low2)
            println("[$low1,$high1] + [$low2,$high2]")
        else
            println("[$low2,$high2] + [$low1,$high1]")
    }
    else {
        // The intervals intersect
        low = if (low1 < low2) low1 else low2 // low is min(low1, low2)
        high = if (high1 > high2) high1 else high2 // high is max(high1, high2)
        println("A+B = [$low,$high]")
    }

}