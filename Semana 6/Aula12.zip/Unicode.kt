

fun main() {
    print("Caráter? ")
//    val ch : Char =  readLine()!![0]
    val ch =  readLine()!![0] // Char type is inferred
    val code = ch.toInt() // Gets unicode
    println("Unicode = $code")
//    if (ch >= 'a' && ch <= 'z')
    // Or, using ranges
    if (ch in 'a'..'z')
        println("Maiúscula = ${ch - 32}")
}